# BeybiOS — Buzlu Cam Android Launcher

Kotlin + Jetpack Compose ile yazılmış, buzlu cam (frosted glass) temalı ana ekran launcher'ı.

## Özellikler

- **Uygulamalar ana sayfada**: Cihazdaki tüm uygulamalar sayfalı ızgara olarak ana ekranda (sağa-sola kaydır). Ayrı bir uygulama çekmecesi yok.
- **Buzlu cam teması**: Arama çubuğu, dock, menüler ve ayar kartları duvar kağıdını gerçekten bulanıklaştırır (Android 12+). Android 8–11'de bulanıklık yerine daha opak cam çizilir.
- **Ayarlar sekmesi** (sağ üstteki dişli ya da boş alana uzun basma):
  - Cam tonu (açık/koyu), bulanıklık, cam yoğunluğu, duvar kağıdı karartma
  - Duvar kağıdı: 4 hazır tema + galeriden fotoğraf
  - Sütun sayısı (4/5/6), simge boyutu, uygulama adları, arama çubuğu, dock
  - Bulanık animasyonlar açık/kapalı, animasyon hızı (yavaş/normal/hızlı)
  - Varsayılan ana ekran yap kısayolu
- **Blurlu, akıcı animasyonlar**:
  - *Açılış*: simge buzlu cam bir perdeye dönüşüp ekranı kaplar, ana ekran bulanıklaşıp büyüyerek solar, uygulama perdenin üstüne yumuşakça belirir.
  - *Kapanış*: uygulamadan dönünce perde simgeye küçülür, ana ekran netleşir.
  - Ayarlar da aşağıdan süzülürken arkadaki ana ekranı bulandırır.
- **Arama**: yazdıkça uygulamalar filtrelenir, Enter ilk sonucu açar.
- **Uzun basma menüsü**: Dock'a sabitle/kaldır, Uygulama bilgisi, Kaldır.
- Yüklenen / silinen uygulamalar listeye otomatik yansır.

## Kurulum

1. Android Studio (Ladybug veya üstü) ile `BeybiOS` klasörünü aç; Gradle senkronizasyonunu bekle.
2. Telefonu USB ile bağla (geliştirici seçenekleri + USB hata ayıklama açık) ya da emülatör kullan.
3. **Run** ile kur. Komut satırından: `./gradlew installDebug`
4. Home tuşuna bas → **BeybiOS**'u seç → **Her zaman**. Ya da uygulamadaki *Ayarlar → Varsayılan ana ekran yap*.

Gereksinimler: Android 8.0 (API 26) ve üzeri. Gerçek bulanıklık için Android 12 (API 31) ve üzeri önerilir.

## Proje yapısı

```
app/src/main/java/com/beybios/launcher/
├── MainActivity.kt            Launcher aktivitesi, uygulama başlatma
├── data/
│   ├── AppRepository.kt       Yüklü uygulamaları okur, varsayılan dock'u bulur
│   ├── LauncherSettings.kt    Ayarlar (Compose state + SharedPreferences)
│   └── LauncherViewModel.kt   Uygulama listesi, dock, duvar kağıdı
└── ui/
    ├── Glass.kt               Duvar kağıdı + GlassSurface (buzlu cam çekirdeği)
    ├── BeybiOSRoot.kt         Katmanlar ve animasyon koordinasyonu
    ├── HomeScreen.kt          Saat, arama, sayfalı ızgara, dock
    ├── LaunchAnimation.kt     Açma/kapama cam perdesi
    ├── SettingsScreen.kt      Ayarlar ekranı
    ├── SettingsComponents.kt  Anahtar, kaydırıcı, seçici bileşenleri
    ├── AppMenu.kt             Uzun basma menüsü
    ├── AppIcon.kt             Simge + basma efekti
    └── Press.kt               Yaylanan dokunma efekti
```

## Nasıl çalışıyor? (kısaca)

- **Cam yüzey**: Her `GlassSurface`, duvar kağıdını kendi ekran konumuna hizalı çizip `RenderEffect` ile bulandırır, üstüne ton + ışıklı kenarlık ekler. Böylece sistem duvar kağıdına erişim izni gerekmeden gerçek "arkasını bulandıran cam" etkisi elde edilir.
- **Animasyon süreleri** `Ayarlar → Animasyon hızı` ile ölçeklenir. Açılan uygulamanın kendi giriş animasyonu (`res/anim/beybios_open_*.xml`) sabit süreli kısa bir belirmedir.

## Bilinen sınırlar

- Duvar kağıdı, launcher'ın kendi hazır temaları veya galeriden seçilen fotoğraftır; sistem duvar kağıdı kullanılmaz (izin gerektirdiği için).
- Uygulama kapanışında sistemin kendi geri dönüş animasyonu da oynar; BeybiOS bunun üstüne ana ekranı netleştirir. Üçüncü taraf uygulamanın kendi kapanış animasyonu launcher tarafından değiştirilemez.
- Ekran dikey modda sabittir.

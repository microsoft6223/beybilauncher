package com.beybios.launcher.ui

import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.beybios.launcher.data.LauncherViewModel
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(vm: LauncherViewModel, onClose: () -> Unit, modifier: Modifier = Modifier) {
    val s = vm.settings
    val context = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.setWallpaperFromUri(uri)
    }

    Column(
        modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.22f))
            // Arkadaki ana ekranın dokunuşları almasını engelle
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        // Üst çubuk
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            GlassSurface(
                modifier = Modifier.size(44.dp).pressable(onClick = onClose),
                shape = CircleShape,
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = Color.White)
            }
            Spacer(Modifier.width(14.dp))
            Text("BeybiOS Ayarları", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        }

        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp),
        ) {
            SettingsSection("Cam görünümü") {
                SettingSegmented("Cam tonu", listOf("Açık", "Koyu"), if (s.darkGlass) 1 else 0) { s.updateDarkGlass(it == 1) }
                SettingSlider("Bulanıklık", s.blurStrength, 0f..1f, "%${(s.blurStrength * 100).roundToInt()}", s::updateBlurStrength)
                SettingSlider("Cam yoğunluğu", s.glassOpacity, 0.05f..0.45f, "%${(s.glassOpacity * 100).roundToInt()}", s::updateGlassOpacity)
                SettingSlider("Duvar kağıdı karartma", s.wallpaperDim, 0f..0.6f, "%${(s.wallpaperDim * 100).roundToInt()}", s::updateWallpaperDim)
            }

            SettingsSection("Duvar kağıdı") {
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    WallpaperPreset.entries.forEachIndexed { i, preset ->
                        WallpaperTile(
                            title = preset.title,
                            selected = s.wallpaperChoice == i,
                            brush = Brush.linearGradient(preset.base + preset.blobs.take(1)),
                            onClick = { s.updateWallpaperChoice(i) },
                        )
                    }
                    WallpaperTile(
                        title = "Galeri",
                        selected = s.wallpaperChoice == -1 && vm.customWallpaper != null,
                        brush = Brush.linearGradient(listOf(Color(0x33FFFFFF), Color(0x11FFFFFF))),
                        onClick = {
                            if (vm.customWallpaper != null && s.wallpaperChoice != -1) {
                                s.updateWallpaperChoice(-1)
                            } else {
                                picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            }
                        },
                        image = vm.customWallpaper,
                    )
                }
                SettingAction(
                    "Galeriden yeni fotoğraf seç",
                    "Seçtiğin fotoğraf buzlu cam arka planı olarak kullanılır",
                ) { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
            }

            SettingsSection("Ana ekran") {
                SettingSegmented("Sütun sayısı", listOf("4", "5", "6"), s.columns - 4) { s.updateColumns(it + 4) }
                SettingSlider("Simge boyutu", s.iconScale, 0.8f..1.25f, "%${(s.iconScale * 100).roundToInt()}", s::updateIconScale)
                SettingSwitch("Uygulama adları", checked = s.showLabels, onChange = s::updateShowLabels)
                SettingSwitch("Arama çubuğu", checked = s.showSearch, onChange = s::updateShowSearch)
                SettingSwitch("Dock", "Alt kısımdaki sabit uygulama çubuğu", s.showDock, s::updateShowDock)
            }

            SettingsSection("Animasyonlar") {
                SettingSwitch(
                    "Bulanık animasyonlar",
                    "Uygulama açılırken/kapanırken ve ayarlarda arka plan bulanır (Android 12+)",
                    s.blurAnimations,
                    s::updateBlurAnimations,
                )
                SettingSegmented("Animasyon hızı", listOf("Yavaş", "Normal", "Hızlı"), s.animSpeed, s::updateAnimSpeed)
            }

            SettingsSection("Sistem") {
                SettingAction("Varsayılan ana ekran yap", "BeybiOS'u ana ekran uygulaması olarak seç") {
                    val intent = Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    runCatching { context.startActivity(intent) }.onFailure {
                        runCatching {
                            context.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        }
                    }
                }
                Column {
                    Text("BeybiOS 1.0", color = Color.White, fontSize = 16.sp)
                    Text("Buzlu cam ana ekran", color = Color.White.copy(alpha = 0.65f), fontSize = 12.sp)
                }
            }

            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun WallpaperTile(
    title: String,
    selected: Boolean,
    brush: Brush,
    onClick: () -> Unit,
    image: androidx.compose.ui.graphics.ImageBitmap? = null,
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.pressable(onClick = onClick)) {
        Box(
            Modifier
                .size(width = 64.dp, height = 96.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(brush)
                .border(
                    width = if (selected) 2.5.dp else 1.dp,
                    color = if (selected) Color.White else Color.White.copy(alpha = 0.3f),
                    shape = RoundedCornerShape(16.dp),
                ),
            contentAlignment = Alignment.Center,
        ) {
            if (image != null) {
                Image(
                    bitmap = image,
                    contentDescription = title,
                    contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
            } else if (title == "Galeri") {
                Text("+", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Light)
            }
        }
        Text(title, color = Color.White.copy(alpha = 0.85f), fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
    }
}

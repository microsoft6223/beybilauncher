package com.beybios.launcher

import android.app.ActivityOptions
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import com.beybios.launcher.data.AppInfo
import com.beybios.launcher.ui.BeybiOSRoot

class MainActivity : ComponentActivity() {

    /** Home tuşuna her basışta artar; arayüz buna bakıp ana ekrana döner. */
    private var homeSignal by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.isNavigationBarContrastEnforced = false
        }
        setContent {
            BeybiOSRoot(
                homeSignal = homeSignal,
                startApp = ::startApp,
                openAppInfo = ::openAppInfo,
                uninstall = ::uninstallApp,
            )
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN && intent.hasCategory(Intent.CATEGORY_HOME)) {
            homeSignal++
        }
    }

    /** Uygulamayı, yumuşak belirme animasyonuyla başlatır. */
    private fun startApp(app: AppInfo): Boolean = try {
        val intent = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setClassName(app.packageName, app.className)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        val options = ActivityOptions.makeCustomAnimation(
            this, R.anim.beybios_open_enter, R.anim.beybios_open_exit,
        )
        startActivity(intent, options.toBundle())
        true
    } catch (e: Exception) {
        Toast.makeText(this, "${app.label} açılamadı", Toast.LENGTH_SHORT).show()
        false
    }

    private fun openAppInfo(app: AppInfo) {
        runCatching {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.packageName}"))
            )
        }
    }

    private fun uninstallApp(app: AppInfo) {
        runCatching {
            startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.packageName}")))
        }
    }
}

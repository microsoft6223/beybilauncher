package com.beybios.launcher.ui

import android.os.Build
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.matchParentSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

/** Cihaz gerçek (RenderEffect) bulanıklığı destekliyor mu? (Android 12+) */
val canBlur: Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S

// ---------------------------------------------------------------------------
// Duvar kağıdı
// ---------------------------------------------------------------------------

enum class WallpaperPreset(val title: String, val base: List<Color>, val blobs: List<Color>) {
    Aurora(
        "Aurora",
        listOf(Color(0xFF0F172A), Color(0xFF1E3A8A), Color(0xFF6D28D9)),
        listOf(Color(0xFF22D3EE), Color(0xFFF472B6), Color(0xFFA78BFA)),
    ),
    Sunset(
        "Gün batımı",
        listOf(Color(0xFF1F1147), Color(0xFF7C2D52), Color(0xFFF97316)),
        listOf(Color(0xFFFB7185), Color(0xFFFBBF24), Color(0xFF8B5CF6)),
    ),
    Ocean(
        "Okyanus",
        listOf(Color(0xFF021B2B), Color(0xFF0B5C7A), Color(0xFF1AA6B7)),
        listOf(Color(0xFF67E8F9), Color(0xFF34D399), Color(0xFF3B82F6)),
    ),
    Mint(
        "Nane",
        listOf(Color(0xFF0B2B26), Color(0xFF14675B), Color(0xFF7ED9B5)),
        listOf(Color(0xFFA7F3D0), Color(0xFF38BDF8), Color(0xFFFDE68A)),
    ),
}

/**
 * Hem ana arka planı hem de her cam yüzeyin içindeki bulanık kopyayı çizen duvar kağıdı.
 * Cam yüzeyler aynı çizimi kendi konumuna göre kaydırıp bulandırdığı için gerçek
 * "arkasını bulanıklaştıran buzlu cam" etkisi oluşur.
 */
@Immutable
class Wallpaper(
    private val preset: WallpaperPreset,
    private val custom: ImageBitmap?,
    private val dim: Float,
) {
    fun draw(scope: DrawScope, size: Size) {
        if (size.width <= 0f || size.height <= 0f) return
        with(scope) {
            val w = size.width
            val h = size.height
            if (custom != null) {
                val targetAspect = w / h
                val imgAspect = custom.width.toFloat() / custom.height
                val srcW: Int
                val srcH: Int
                if (imgAspect > targetAspect) {
                    srcH = custom.height
                    srcW = (custom.height * targetAspect).toInt()
                } else {
                    srcW = custom.width
                    srcH = (custom.width / targetAspect).toInt()
                }
                drawImage(
                    image = custom,
                    srcOffset = IntOffset((custom.width - srcW) / 2, (custom.height - srcH) / 2),
                    srcSize = IntSize(srcW, srcH),
                    dstSize = IntSize(w.roundToInt(), h.roundToInt()),
                )
            } else {
                drawRect(
                    brush = Brush.linearGradient(
                        colors = preset.base,
                        start = Offset.Zero,
                        end = Offset(w, h),
                    ),
                    size = size,
                )
                val spots = listOf(
                    Offset(0.15f * w, 0.18f * h) to 0.75f * w,
                    Offset(0.90f * w, 0.45f * h) to 0.80f * w,
                    Offset(0.25f * w, 0.88f * h) to 0.85f * w,
                )
                spots.forEachIndexed { i, (center, radius) ->
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(preset.blobs[i].copy(alpha = 0.8f), Color.Transparent),
                            center = center,
                            radius = radius,
                        ),
                        radius = radius,
                        center = center,
                    )
                }
            }
            if (dim > 0f) drawRect(Color.Black.copy(alpha = dim), size = size)
        }
    }
}

// ---------------------------------------------------------------------------
// Cam stili (tüm cam yüzeyler bunu okur)
// ---------------------------------------------------------------------------

@Immutable
data class GlassStyle(
    val wallpaper: Wallpaper,
    val screen: Size,
    val blurPx: Float,
    val tint: Color,
    val opacity: Float,
)

val LocalGlass = staticCompositionLocalOf<GlassStyle> { error("GlassStyle sağlanmadı") }

private val GlassBorder = Brush.linearGradient(
    listOf(Color.White.copy(alpha = 0.60f), Color.White.copy(alpha = 0.08f), Color.White.copy(alpha = 0.28f))
)
private val GlassSheen = Brush.verticalGradient(
    listOf(Color.White.copy(alpha = 0.16f), Color.Transparent)
)

/**
 * Buzlu cam yüzey:
 *  1) duvar kağıdının ekrandaki yerine hizalı, bulanıklaştırılmış kopyası
 *  2) renk tonu (açık/koyu) + üstten parlama
 *  3) ince ışıklı kenarlık
 * Android 12 altında bulanıklık yok; yerine cam biraz daha opak çizilir.
 */
@Composable
fun GlassSurface(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(28.dp),
    contentAlignment: Alignment = Alignment.TopStart,
    content: @Composable BoxScope.() -> Unit,
) {
    val style = LocalGlass.current
    var origin by remember { mutableStateOf(Offset.Zero) }
    val opacity = if (canBlur) style.opacity else (style.opacity + 0.14f).coerceAtMost(0.6f)

    Box(
        modifier = modifier
            .onGloballyPositioned { origin = it.positionInRoot() }
            .clip(shape),
        contentAlignment = contentAlignment,
    ) {
        Canvas(
            Modifier
                .matchParentSize()
                .graphicsLayer {
                    clip = true
                    if (canBlur && style.blurPx > 0.5f) {
                        renderEffect = BlurEffect(style.blurPx, style.blurPx, TileMode.Clamp)
                    }
                }
        ) {
            translate(-origin.x, -origin.y) { style.wallpaper.draw(this, style.screen) }
        }
        Box(
            Modifier
                .matchParentSize()
                .background(style.tint.copy(alpha = opacity))
                .background(GlassSheen)
                .border(1.dp, GlassBorder, shape)
        )
        content()
    }
}

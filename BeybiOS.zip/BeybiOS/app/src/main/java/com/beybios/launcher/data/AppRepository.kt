package com.beybios.launcher.data

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.MediaStore
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale

@Immutable
data class AppInfo(
    val label: String,
    val packageName: String,
    val className: String,
    val icon: ImageBitmap,
) {
    val key: String get() = "$packageName/$className"
}

object AppRepository {

    /** Cihazdaki tüm başlatılabilir uygulamaları (kendimiz hariç) alfabetik döndürür. */
    suspend fun load(context: Context, iconPx: Int = 192): List<AppInfo> =
        withContext(Dispatchers.Default) {
            val pm = context.packageManager
            val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            pm.queryIntentActivities(query, 0)
                .filter { it.activityInfo.packageName != context.packageName }
                .distinctBy { it.activityInfo.packageName + "/" + it.activityInfo.name }
                .mapNotNull { ri ->
                    runCatching {
                        AppInfo(
                            label = ri.loadLabel(pm).toString(),
                            packageName = ri.activityInfo.packageName,
                            className = ri.activityInfo.name,
                            icon = ri.loadIcon(pm).toBitmap(iconPx, iconPx).asImageBitmap(),
                        )
                    }.getOrNull()
                }
                .sortedBy { it.label.lowercase(Locale.getDefault()) }
        }

    /** İlk açılışta dock'a konacak uygulamalar: telefon, mesajlar, tarayıcı, kamera. */
    fun defaultDock(context: Context, apps: List<AppInfo>): List<String> {
        val pm = context.packageManager
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_VIEW, Uri.parse("sms:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE),
        )
        return intents.mapNotNull { intent ->
            val pkg = pm.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
                ?.activityInfo?.packageName
            apps.firstOrNull { it.packageName == pkg }?.key
        }.distinct()
    }
}

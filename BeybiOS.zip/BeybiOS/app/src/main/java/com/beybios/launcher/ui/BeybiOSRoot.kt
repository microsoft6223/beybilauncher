package com.beybios.launcher.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.viewmodel.compose.viewModel
import com.beybios.launcher.data.AppInfo
import com.beybios.launcher.data.LauncherViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun BeybiOSRoot(
    homeSignal: Int,
    startApp: (AppInfo) -> Boolean,
    openAppInfo: (AppInfo) -> Unit,
    uninstall: (AppInfo) -> Unit,
    vm: LauncherViewModel = viewModel(),
) {
    val s = vm.settings
    val scope = rememberCoroutineScope()
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val density = LocalDensity.current
    val ctrl = remember { LaunchController() }

    var showSettings by rememberSaveable { mutableStateOf(false) }
    var menuApp by remember { mutableStateOf<AppInfo?>(null) }
    var menuVisible by remember { mutableStateOf(false) }
    var screen by remember { mutableStateOf(Size.Zero) }

    val dur = s.durationScale

    // --- Cam stili: duvar kağıdı + ton + bulanıklık ---
    val presets = WallpaperPreset.entries
    val preset = presets[s.wallpaperChoice.coerceIn(0, presets.size - 1)]
    val custom = if (s.wallpaperChoice == -1) vm.customWallpaper else null
    val wallpaper = remember(preset, custom, s.wallpaperDim) { Wallpaper(preset, custom, s.wallpaperDim) }
    val blurPx = with(density) { (6f + 34f * s.blurStrength).dp.toPx() }
    val tint = if (s.darkGlass) Color(0xFF0B1220) else Color.White
    val style = remember(wallpaper, screen, blurPx, tint, s.glassOpacity) {
        GlassStyle(wallpaper, screen, blurPx, tint, s.glassOpacity)
    }

    // Ayarlar açılış/kapanış ilerlemesi (0..1)
    val sp by animateFloatAsState(
        targetValue = if (showSettings) 1f else 0f,
        animationSpec = tween((420 * dur).toInt(), easing = FastOutSlowInEasing),
        label = "settings",
    )

    // --- Uygulama açma / kapama ---
    suspend fun closeApp() {
        ctrl.away = false
        ctrl.progress.animateTo(0f, tween((360 * dur).toInt(), easing = FastOutSlowInEasing))
        ctrl.target = null
    }

    fun openApp(app: AppInfo, rect: Rect?) {
        if (ctrl.target != null) return
        val origin = rect ?: Rect(
            Offset(screen.width / 2f - 60f, screen.height / 2f - 60f),
            Size(120f, 120f),
        )
        ctrl.target = LaunchTarget(app, origin)
        scope.launch {
            ctrl.progress.snapTo(0f)
            ctrl.progress.animateTo(1f, tween((400 * dur).toInt(), easing = FastOutSlowInEasing))
            if (startApp(app)) {
                ctrl.away = true
                // Uygulama öne geçmediyse (ör. iptal edildi) perdeyi geri çek
                delay(1500)
                if (ctrl.away && lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) closeApp()
            } else {
                closeApp()
            }
        }
    }

    // Uygulamadan ana ekrana dönünce: perde simgeye küçülür, ana ekran netleşir
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        if (ctrl.away) scope.launch { closeApp() }
    }

    // Home tuşu: ayarları ve menüyü kapat
    LaunchedEffect(homeSignal) {
        if (homeSignal > 0) {
            showSettings = false
            menuVisible = false
        }
    }

    BackHandler(enabled = menuVisible || showSettings) {
        if (menuVisible) menuVisible = false else showSettings = false
    }

    MaterialTheme(colorScheme = darkColorScheme()) {
        CompositionLocalProvider(LocalGlass provides style) {
            Box(
                Modifier
                    .fillMaxSize()
                    .onSizeChanged { screen = Size(it.width.toFloat(), it.height.toFloat()) }
            ) {
                // 1) Duvar kağıdı
                Canvas(Modifier.fillMaxSize()) { wallpaper.draw(this, size) }

                // 2) Ana ekran: uygulama açılırken ve ayarlar açıkken büyür/solar/bulanır
                Box(
                    Modifier
                        .fillMaxSize()
                        .graphicsLayer {
                            val lp = ctrl.progress.value
                            val scale = (1f + 0.10f * lp) * (1f - 0.05f * sp)
                            scaleX = scale
                            scaleY = scale
                            alpha = (1f - 0.5f * lp - 0.3f * sp).coerceIn(0f, 1f)
                            if (canBlur && s.blurAnimations) {
                                // this.density: GraphicsLayerScope'un piksel yoğunluğu (Float)
                                val r = (34f * lp + 26f * sp) * this.density
                                if (r > 0.5f) renderEffect = BlurEffect(r, r, TileMode.Decal)
                            }
                        }
                ) {
                    HomeScreen(
                        vm = vm,
                        homeSignal = homeSignal,
                        onOpenSettings = { showSettings = true },
                        onLaunch = ::openApp,
                        onLongPress = { app ->
                            menuApp = app
                            menuVisible = true
                        },
                    )
                }

                // 3) Cam perde (simgeden tam ekrana)
                LaunchOverlay(ctrl, screen)

                // 4) Uzun basma menüsü
                AppMenu(
                    visible = menuVisible,
                    app = menuApp,
                    pinned = menuApp?.let { vm.isPinned(it) } ?: false,
                    durationMs = (220 * dur).toInt(),
                    onDismiss = { menuVisible = false },
                    onTogglePin = {
                        menuApp?.let { vm.togglePin(it) }
                        menuVisible = false
                    },
                    onInfo = {
                        menuApp?.let(openAppInfo)
                        menuVisible = false
                    },
                    onUninstall = {
                        menuApp?.let(uninstall)
                        menuVisible = false
                    },
                )

                // 5) Ayarlar: aşağıdan süzülerek, arkadaki ana ekranı bulandırarak açılır
                if (showSettings || sp > 0.001f) {
                    SettingsScreen(
                        vm = vm,
                        onClose = { showSettings = false },
                        modifier = Modifier.graphicsLayer {
                            alpha = sp
                            translationY = (1f - sp) * 56.dp.toPx()
                            val sc = 0.96f + 0.04f * sp
                            scaleX = sc
                            scaleY = sc
                        },
                    )
                }
            }
        }
    }
}

package com.beybios.launcher.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.beybios.launcher.data.AppInfo

/**
 * Bir uygulamaya uzun basınca açılan buzlu cam menü.
 * [app] menü kapanırken de içeriği korumak için kapanış animasyonu bitene kadar dolu kalır.
 */
@Composable
fun AppMenu(
    visible: Boolean,
    app: AppInfo?,
    pinned: Boolean,
    durationMs: Int,
    onDismiss: () -> Unit,
    onTogglePin: () -> Unit,
    onInfo: () -> Unit,
    onUninstall: () -> Unit,
) {
    AnimatedVisibility(
        visible = visible && app != null,
        enter = fadeIn(tween(durationMs)),
        exit = fadeOut(tween(durationMs)),
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.32f))
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onDismiss() },
            contentAlignment = Alignment.Center,
        ) {
            if (app != null) {
                // Kart, perdeyle birlikte hafifçe büyüyerek belirir, kapanırken küçülür
                PopScale(visible, durationMs) {
                    MenuCard(app, pinned, onTogglePin, onInfo, onUninstall)
                }
            }
        }
    }
}

@Composable
private fun PopScale(visible: Boolean, durationMs: Int, content: @Composable () -> Unit) {
    var entered by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { entered = true }
    val scale by animateFloatAsState(
        targetValue = when {
            !entered -> 0.86f
            visible -> 1f
            else -> 0.92f
        },
        animationSpec = tween(durationMs, easing = FastOutSlowInEasing),
        label = "menuPop",
    )
    Box(
        Modifier.graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
    ) { content() }
}

@Composable
private fun MenuCard(
    app: AppInfo,
    pinned: Boolean,
    onTogglePin: () -> Unit,
    onInfo: () -> Unit,
    onUninstall: () -> Unit,
) {
    GlassSurface(
        modifier = Modifier
            .width(280.dp)
            // Karta dokununca perde kapanmasın
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { },
        shape = RoundedCornerShape(28.dp),
    ) {
        Column(Modifier.padding(vertical = 8.dp)) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Image(
                    bitmap = app.icon,
                    contentDescription = null,
                    modifier = Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)),
                )
                Spacer(Modifier.width(14.dp))
                Text(
                    app.label,
                    color = Color.White,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Divider()
            MenuRow(if (pinned) "Dock'tan kaldır" else "Dock'a sabitle", onTogglePin)
            Divider()
            MenuRow("Uygulama bilgisi", onInfo)
            Divider()
            MenuRow("Kaldır", onUninstall, danger = true)
        }
    }
}

@Composable
private fun Divider() {
    Box(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 18.dp)
            .height(1.dp)
            .background(Color.White.copy(alpha = 0.14f))
    )
}

@Composable
private fun MenuRow(text: String, onClick: () -> Unit, danger: Boolean = false) {
    Text(
        text = text,
        color = if (danger) Color(0xFFFF8A80) else Color.White,
        fontSize = 16.sp,
        modifier = Modifier
            .fillMaxWidth()
            .pressable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 14.dp),
    )
}

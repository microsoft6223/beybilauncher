package com.beybios.launcher.data

import android.app.Application
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.max

class LauncherViewModel(app: Application) : AndroidViewModel(app) {

    val settings = LauncherSettings(app)

    var apps by mutableStateOf<List<AppInfo>>(emptyList())
        private set

    /** Galeriden seçilen duvar kağıdı (yoksa null) */
    var customWallpaper by mutableStateOf<ImageBitmap?>(null)
        private set

    private val wallpaperFile = File(app.filesDir, "wallpaper.jpg")

    // Uygulama yüklendi / kaldırıldı / güncellendi -> listeyi yenile
    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            reload()
        }
    }

    init {
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(app, packageReceiver, filter, ContextCompat.RECEIVER_EXPORTED)
        reload()
        loadSavedWallpaper()
    }

    fun reload() {
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            val list = AppRepository.load(ctx)
            apps = list
            if (!settings.dockInitialized) {
                settings.updateDock(AppRepository.defaultDock(ctx, list))
            }
        }
    }

    /** Dock'ta olan uygulamalar (kaldırılmış olanlar elenir). */
    fun dockApps(): List<AppInfo> =
        settings.dock.mapNotNull { key -> apps.firstOrNull { it.key == key } }

    fun isPinned(app: AppInfo): Boolean = app.key in settings.dock

    fun togglePin(app: AppInfo) {
        val current = settings.dock
        settings.updateDock(
            if (app.key in current) current - app.key else (current + app.key).takeLast(5)
        )
    }

    // ---- Duvar kağıdı ----

    private fun loadSavedWallpaper() {
        viewModelScope.launch {
            val bmp = withContext(Dispatchers.IO) {
                if (wallpaperFile.exists()) BitmapFactory.decodeFile(wallpaperFile.path) else null
            }
            customWallpaper = bmp?.asImageBitmap()
        }
    }

    fun setWallpaperFromUri(uri: Uri) {
        viewModelScope.launch {
            val bmp = withContext(Dispatchers.IO) {
                runCatching { decodeScaled(uri) }.getOrNull()?.also { b ->
                    wallpaperFile.outputStream().use { b.compress(Bitmap.CompressFormat.JPEG, 90, it) }
                }
            }
            if (bmp != null) {
                customWallpaper = bmp.asImageBitmap()
                settings.updateWallpaperChoice(-1)
            }
        }
    }

    /** Büyük fotoğrafları ~1920px'e küçülterek açar (EXIF yönünü API 28+ düzeltir). */
    private fun decodeScaled(uri: Uri): Bitmap? {
        val cr = getApplication<Application>().contentResolver
        val target = 1920
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            ImageDecoder.decodeBitmap(ImageDecoder.createSource(cr, uri)) { decoder, info, _ ->
                val sample = max(info.size.width, info.size.height) / target
                if (sample > 1) decoder.setTargetSampleSize(sample)
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            }
        } else {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            val opts = BitmapFactory.Options().apply {
                inSampleSize = max(1, max(bounds.outWidth, bounds.outHeight) / target)
            }
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        }
    }

    override fun onCleared() {
        runCatching { getApplication<Application>().unregisterReceiver(packageReceiver) }
        super.onCleared()
    }
}

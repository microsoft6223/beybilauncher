package com.beybios.launcher.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * Launcher ayarları. Her alan Compose state'i; değişince arayüz anında güncellenir
 * ve değer SharedPreferences'a yazılır.
 */
class LauncherSettings(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("beybios_settings", Context.MODE_PRIVATE)

    // --- Cam görünümü ---
    var darkGlass by mutableStateOf(prefs.getBoolean("darkGlass", false)); private set
    var glassOpacity by mutableFloatStateOf(prefs.getFloat("glassOpacity", 0.18f)); private set
    var blurStrength by mutableFloatStateOf(prefs.getFloat("blurStrength", 0.6f)); private set
    var wallpaperDim by mutableFloatStateOf(prefs.getFloat("wallpaperDim", 0.12f)); private set

    /** 0..3 = hazır duvar kağıdı, -1 = galeriden seçilen */
    var wallpaperChoice by mutableIntStateOf(prefs.getInt("wallpaperChoice", 0)); private set

    // --- Ana ekran ---
    var columns by mutableIntStateOf(prefs.getInt("columns", 4)); private set
    var iconScale by mutableFloatStateOf(prefs.getFloat("iconScale", 1f)); private set
    var showLabels by mutableStateOf(prefs.getBoolean("showLabels", true)); private set
    var showSearch by mutableStateOf(prefs.getBoolean("showSearch", true)); private set
    var showDock by mutableStateOf(prefs.getBoolean("showDock", true)); private set

    // --- Animasyonlar ---
    var blurAnimations by mutableStateOf(prefs.getBoolean("blurAnimations", true)); private set

    /** 0 = yavaş, 1 = normal, 2 = hızlı */
    var animSpeed by mutableIntStateOf(prefs.getInt("animSpeed", 1)); private set

    // --- Dock ---
    var dock by mutableStateOf(
        prefs.getString("dock", "").orEmpty().split(",").filter { it.isNotBlank() }
    ); private set
    val dockInitialized: Boolean get() = prefs.getBoolean("dockInit", false)

    /** Süre çarpanı: yavaş 1.5x, normal 1x, hızlı 0.7x */
    val durationScale: Float
        get() = when (animSpeed) {
            0 -> 1.5f
            2 -> 0.7f
            else -> 1f
        }

    fun updateDarkGlass(v: Boolean) { darkGlass = v; prefs.edit().putBoolean("darkGlass", v).apply() }
    fun updateGlassOpacity(v: Float) { glassOpacity = v; prefs.edit().putFloat("glassOpacity", v).apply() }
    fun updateBlurStrength(v: Float) { blurStrength = v; prefs.edit().putFloat("blurStrength", v).apply() }
    fun updateWallpaperDim(v: Float) { wallpaperDim = v; prefs.edit().putFloat("wallpaperDim", v).apply() }
    fun updateWallpaperChoice(v: Int) { wallpaperChoice = v; prefs.edit().putInt("wallpaperChoice", v).apply() }
    fun updateColumns(v: Int) { columns = v; prefs.edit().putInt("columns", v).apply() }
    fun updateIconScale(v: Float) { iconScale = v; prefs.edit().putFloat("iconScale", v).apply() }
    fun updateShowLabels(v: Boolean) { showLabels = v; prefs.edit().putBoolean("showLabels", v).apply() }
    fun updateShowSearch(v: Boolean) { showSearch = v; prefs.edit().putBoolean("showSearch", v).apply() }
    fun updateShowDock(v: Boolean) { showDock = v; prefs.edit().putBoolean("showDock", v).apply() }
    fun updateBlurAnimations(v: Boolean) { blurAnimations = v; prefs.edit().putBoolean("blurAnimations", v).apply() }
    fun updateAnimSpeed(v: Int) { animSpeed = v; prefs.edit().putInt("animSpeed", v).apply() }

    fun updateDock(keys: List<String>) {
        dock = keys
        prefs.edit().putString("dock", keys.joinToString(",")).putBoolean("dockInit", true).apply()
    }
}

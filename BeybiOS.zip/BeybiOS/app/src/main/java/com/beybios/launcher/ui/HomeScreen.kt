package com.beybios.launcher.ui

import android.text.format.DateFormat
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.beybios.launcher.data.AppInfo
import com.beybios.launcher.data.LauncherSettings
import com.beybios.launcher.data.LauncherViewModel
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.max

private val TextShadow = Shadow(Color.Black.copy(alpha = 0.35f), Offset(0f, 3f), 10f)

@Composable
fun HomeScreen(
    vm: LauncherViewModel,
    homeSignal: Int,
    onOpenSettings: () -> Unit,
    onLaunch: (AppInfo, Rect?) -> Unit,
    onLongPress: (AppInfo) -> Unit,
    modifier: Modifier = Modifier,
) {
    val s = vm.settings
    val focus = LocalFocusManager.current
    var query by rememberSaveable { mutableStateOf("") }
    val results = remember(vm.apps, query) {
        val q = query.trim()
        if (q.isEmpty()) vm.apps else vm.apps.filter { it.label.contains(q, ignoreCase = true) }
    }

    // Home tuşuna tekrar basılınca aramayı temizle
    LaunchedEffect(homeSignal) {
        if (homeSignal > 0) {
            query = ""
            focus.clearFocus()
        }
    }

    Column(
        modifier
            .fillMaxSize()
            // Boş alana uzun basınca ayarlar açılır
            .pointerInput(Unit) { detectTapGestures(onLongPress = { onOpenSettings() }) }
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp)
    ) {
        ClockHeader(onOpenSettings)

        if (s.showSearch) {
            SearchBar(
                query = query,
                onQuery = { query = it },
                onGo = {
                    results.firstOrNull()?.let { app ->
                        focus.clearFocus()
                        query = ""
                        onLaunch(app, null)
                    }
                },
            )
        }

        Box(Modifier.weight(1f)) {
            if (query.isBlank()) {
                PagedGrid(vm.apps, s, homeSignal, onLaunch, onLongPress)
            } else {
                ResultGrid(results, s, onLaunch = { app, r -> focus.clearFocus(); query = ""; onLaunch(app, r) }, onLongPress)
            }
        }

        if (s.showDock && query.isBlank()) {
            Dock(vm.dockApps(), 56.dp * s.iconScale, onLaunch, onLongPress)
        }
    }
}

// ---------------------------------------------------------------------------
// Saat + ayarlar düğmesi
// ---------------------------------------------------------------------------

@Composable
private fun ClockHeader(onOpenSettings: () -> Unit) {
    val context = LocalContext.current
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = LocalDateTime.now()
            delay(15_000)
        }
    }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { now = LocalDateTime.now() }

    val is24 = DateFormat.is24HourFormat(context)
    val time = now.format(DateTimeFormatter.ofPattern(if (is24) "HH:mm" else "h:mm", Locale.getDefault()))
    val date = now.format(DateTimeFormatter.ofPattern("d MMMM, EEEE", Locale.getDefault()))

    Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.Top) {
        Column(Modifier.weight(1f)) {
            Text(
                text = time,
                color = Color.White,
                fontSize = 64.sp,
                fontWeight = FontWeight.Light,
                style = TextStyle(shadow = TextShadow),
            )
            Text(
                text = date,
                color = Color.White.copy(alpha = 0.88f),
                fontSize = 16.sp,
                style = TextStyle(shadow = TextShadow),
            )
        }
        GlassSurface(
            modifier = Modifier.padding(top = 8.dp).size(46.dp).pressable(onClick = onOpenSettings),
            shape = CircleShape,
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Default.Settings, contentDescription = "Ayarlar", tint = Color.White, modifier = Modifier.size(24.dp))
        }
    }
}

// ---------------------------------------------------------------------------
// Arama çubuğu
// ---------------------------------------------------------------------------

@Composable
private fun SearchBar(query: String, onQuery: (String) -> Unit, onGo: () -> Unit) {
    GlassSurface(
        modifier = Modifier.fillMaxWidth().padding(top = 14.dp).height(48.dp),
        shape = RoundedCornerShape(24.dp),
        contentAlignment = Alignment.CenterStart,
    ) {
        Row(Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Search, null, tint = Color.White.copy(alpha = 0.85f), modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(10.dp))
            Box(Modifier.weight(1f)) {
                if (query.isEmpty()) {
                    Text("Uygulama ara", color = Color.White.copy(alpha = 0.65f), fontSize = 16.sp)
                }
                BasicTextField(
                    value = query,
                    onValueChange = onQuery,
                    singleLine = true,
                    textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                    cursorBrush = SolidColor(Color.White),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { onGo() }),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            if (query.isNotEmpty()) {
                Icon(
                    Icons.Default.Close,
                    contentDescription = "Temizle",
                    tint = Color.White.copy(alpha = 0.85f),
                    modifier = Modifier.size(20.dp).pressable { onQuery("") },
                )
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Sayfalı uygulama ızgarası (uygulamalar ana sayfada)
// ---------------------------------------------------------------------------

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun PagedGrid(
    apps: List<AppInfo>,
    s: LauncherSettings,
    homeSignal: Int,
    onLaunch: (AppInfo, Rect?) -> Unit,
    onLongPress: (AppInfo) -> Unit,
) {
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val iconSize = 60.dp * s.iconScale
        val cellHeight = iconSize + (if (s.showLabels) 26.dp else 0.dp) + 28.dp
        val dotsHeight = 28.dp
        val rows = max(1, ((maxHeight - dotsHeight) / cellHeight).toInt())
        val columns = s.columns
        val perPage = rows * columns
        val pages = remember(apps, perPage) { apps.chunked(perPage).ifEmpty { listOf(emptyList()) } }
        val pagerState = rememberPagerState(pageCount = { pages.size })

        LaunchedEffect(homeSignal) {
            if (homeSignal > 0) pagerState.animateScrollToPage(0)
        }

        Column(Modifier.fillMaxSize()) {
            HorizontalPager(
                state = pagerState,
                modifier = Modifier.weight(1f),
                beyondViewportPageCount = 1,
            ) { page ->
                val pageApps = pages[page]
                Column(Modifier.fillMaxSize()) {
                    repeat(rows) { r ->
                        Row(Modifier.weight(1f).fillMaxWidth()) {
                            repeat(columns) { c ->
                                val app = pageApps.getOrNull(r * columns + c)
                                Box(
                                    Modifier.weight(1f).fillMaxHeight(),
                                    contentAlignment = Alignment.Center,
                                ) {
                                    if (app != null) {
                                        AppIcon(app, iconSize, s.showLabels, onLaunch, onLongPress)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            PageDots(pagerState, pages.size, Modifier.height(dotsHeight))
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun PageDots(state: PagerState, count: Int, modifier: Modifier = Modifier) {
    Row(
        modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (count > 1) {
            repeat(count) { i ->
                val selected = state.currentPage == i
                val w by animateDpAsState(if (selected) 18.dp else 6.dp, label = "dot")
                Box(
                    Modifier
                        .padding(horizontal = 3.dp)
                        .height(6.dp)
                        .width(w)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = if (selected) 0.95f else 0.4f))
                )
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Arama sonuçları
// ---------------------------------------------------------------------------

@Composable
private fun ResultGrid(
    results: List<AppInfo>,
    s: LauncherSettings,
    onLaunch: (AppInfo, Rect?) -> Unit,
    onLongPress: (AppInfo) -> Unit,
) {
    if (results.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Sonuç bulunamadı", color = Color.White.copy(alpha = 0.8f), fontSize = 16.sp)
        }
        return
    }
    LazyVerticalGrid(
        columns = GridCells.Fixed(s.columns),
        contentPadding = PaddingValues(vertical = 12.dp),
        modifier = Modifier.fillMaxSize(),
    ) {
        items(results, key = { it.key }) { app ->
            AppIcon(
                app = app,
                size = 60.dp * s.iconScale,
                showLabel = s.showLabels,
                onLaunch = onLaunch,
                onLongPress = onLongPress,
                modifier = Modifier.padding(vertical = 10.dp),
            )
        }
    }
}

// ---------------------------------------------------------------------------
// Dock
// ---------------------------------------------------------------------------

@Composable
private fun Dock(
    apps: List<AppInfo>,
    iconSize: Dp,
    onLaunch: (AppInfo, Rect?) -> Unit,
    onLongPress: (AppInfo) -> Unit,
) {
    GlassSurface(
        modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp),
        shape = RoundedCornerShape(34.dp),
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 14.dp),
            horizontalArrangement = if (apps.isEmpty()) Arrangement.Center else Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (apps.isEmpty()) {
                Text(
                    "Dock boş · bir uygulamaya uzun basıp sabitle",
                    color = Color.White.copy(alpha = 0.75f),
                    fontSize = 13.sp,
                    modifier = Modifier.padding(vertical = 18.dp),
                )
            }
            apps.forEach { app ->
                AppIcon(app, iconSize, false, onLaunch, onLongPress)
            }
        }
    }
}

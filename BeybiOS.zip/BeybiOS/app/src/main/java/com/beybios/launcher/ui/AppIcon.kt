package com.beybios.launcher.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.beybios.launcher.data.AppInfo

/**
 * Tek bir uygulama simgesi. Dokununca simgenin ekrandaki konumunu (açılış animasyonunun
 * başlangıç noktası) [onLaunch] ile bildirir.
 */
@Composable
fun AppIcon(
    app: AppInfo,
    size: Dp,
    showLabel: Boolean,
    onLaunch: (AppInfo, Rect?) -> Unit,
    onLongPress: (AppInfo) -> Unit,
    modifier: Modifier = Modifier,
) {
    // Düz bir tutucu: state değil, sadece tıklama anında okunur.
    val holder = remember { arrayOfNulls<LayoutCoordinates>(1) }

    Column(
        modifier = modifier.pressable(onLongClick = { onLongPress(app) }) {
            val bounds = holder[0]?.takeIf { it.isAttached }?.boundsInRoot()
            onLaunch(app, bounds)
        },
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Image(
            bitmap = app.icon,
            contentDescription = app.label,
            modifier = Modifier
                .size(size)
                .onGloballyPositioned { holder[0] = it }
                .clip(RoundedCornerShape(size * 0.26f)),
        )
        if (showLabel) {
            Text(
                text = app.label,
                color = Color.White,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                style = TextStyle(shadow = Shadow(Color.Black.copy(alpha = 0.45f), Offset(0f, 2f), 6f)),
                modifier = Modifier
                    .padding(top = 6.dp)
                    .widthIn(max = size + 28.dp),
            )
        }
    }
}

package com.beybios.launcher.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.util.lerp
import com.beybios.launcher.data.AppInfo
import kotlin.math.roundToInt

/** Açılan uygulama ve simgesinin başlangıç dikdörtgeni. */
@Immutable
class LaunchTarget(val app: AppInfo, val origin: Rect)

/**
 * Uygulama açma/kapama animasyonunun durumu.
 * progress: 0 = ana ekran net, 1 = cam perde ekranı tamamen kapladı (uygulama önde).
 */
@Stable
class LaunchController {
    val progress = Animatable(0f)
    var target by mutableStateOf<LaunchTarget?>(null)

    /** Uygulama başlatıldı, launcher arka planda bekliyor. */
    var away = false
}

/**
 * Simgeden ekranın tamamına genişleyen (ve geri dönerken simgeye küçülen) buzlu cam perde.
 * Açılan uygulama bu perdenin üstüne yumuşakça belirir (bkz. res/anim/beybios_open_enter).
 */
@Composable
fun LaunchOverlay(ctrl: LaunchController, screen: Size) {
    val t = ctrl.target ?: return
    if (screen.width <= 0f || screen.height <= 0f) return

    val p = ctrl.progress.value.coerceIn(0f, 1f)
    val density = LocalDensity.current
    val style = LocalGlass.current

    val left = lerp(t.origin.left, 0f, p)
    val top = lerp(t.origin.top, 0f, p)
    val right = lerp(t.origin.right, screen.width, p)
    val bottom = lerp(t.origin.bottom, screen.height, p)
    val corner = with(density) { lerp(t.origin.width * 0.26f, 0f, p).toDp() }
    val iconPx = lerp(t.origin.width, t.origin.width * 1.7f, p)

    Box(
        Modifier
            .offset { IntOffset(left.roundToInt(), top.roundToInt()) }
            .size(
                with(density) { (right - left).toDp() },
                with(density) { (bottom - top).toDp() },
            )
    ) {
        GlassSurface(Modifier.fillMaxSize(), RoundedCornerShape(corner)) {
            // Genişledikçe perde koyulaşır: açılan uygulama temiz bir zemine belirir
            Box(Modifier.fillMaxSize().background(style.tint.copy(alpha = 0.55f * p)))
            Image(
                bitmap = t.app.icon,
                contentDescription = null,
                modifier = Modifier
                    .align(Alignment.Center)
                    .size(with(density) { iconPx.toDp() })
                    .graphicsLayer { alpha = (1f - p * 1.5f).coerceIn(0f, 1f) },
            )
        }
    }
}
